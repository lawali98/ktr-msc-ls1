package dao;
import java.util.List;

import javax.persistence.EntityManager;

import dao.IProfileDao;
import entities.Profile;
import javax.persistence.EntityTransaction;
import util.JpaUtil;

public class ProfileImpl implements IProfileDao {

	private EntityManager entityManager = JpaUtil.getEntityManager("bcManagement");

	@Override
	public Profile save(Profile profile) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
		entityManager.persist(profile);
		et.commit();
		return profile;
	}

	@Override
	public Profile getProfile(Long id) {
		return null;
	}

	@Override
	public Profile findProfileByName(String name) {
		List<Profile> list = entityManager.createQuery("select p from Profile p where p.name like :name").setParameter("name", "%" + name + "%").getResultList();
		Profile profile = list.get(0);
		return profile;
	}
	
	

}
