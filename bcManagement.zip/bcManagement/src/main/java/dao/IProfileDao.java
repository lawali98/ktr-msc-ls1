package dao;

import entities.Profile;

public interface IProfileDao {
	public Profile save(Profile profile);

	public Profile getProfile(Long id);
	
	public Profile findProfileByName(String name);
}
