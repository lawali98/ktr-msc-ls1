package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.passAuthUtil;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import dao.ProfileImpl;
import entities.Profile;

/**
 * Servlet implementation class ProfileServlet
 */
@WebServlet(name = "cp", urlPatterns = { "/create_profile" })
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ProfileImpl profileImpl;
	
    public void init() {
    	profileImpl = new ProfileImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/create_profile.jsp");
    	dispatcher.forward(request, response);	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String companyName = request.getParameter("companyName");
        String email = request.getParameter("email");
        String phoneNum = request.getParameter("phoneNum");
        String password = request.getParameter("password");
        
        IvParameterSpec ivParameterSpec = passAuthUtil.generateIv();
        String algorithm = "AES/CBC/PKCS5Padding";
        String cipherText = null;
		try {
			
	        SecretKey key = null;
			try {
				key = passAuthUtil.generateKey(128);
			} catch (NoSuchAlgorithmException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			cipherText = passAuthUtil.encrypt(algorithm, password, key, ivParameterSpec);
		} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException
				| InvalidAlgorithmParameterException | BadPaddingException | IllegalBlockSizeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
        
        
        Profile profile = new Profile();
		profile.setName(name);
		profile.setCompanyName(companyName);
		profile.setEmail(email);
		profile.setPhoneNum(phoneNum);
		profile.setPassword(cipherText); 

        try {
        	profileImpl.save(profile);
        	
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/create_profile.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}

}
