package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.passAuthUtil;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import dao.ProfileImpl;
import entities.Profile;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name = "login", urlPatterns = { "/login" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ProfileImpl profileImpl;

	public void init() {
		profileImpl = new ProfileImpl();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/login.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("name");
		String password = request.getParameter("password");
		
		Profile profile = profileImpl.findProfileByName(name);

		   SecretKey key = null;
		try {
			key = passAuthUtil.generateKey(128);
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		    IvParameterSpec ivParameterSpec = passAuthUtil.generateIv();
		    String algorithm = "AES/CBC/PKCS5Padding";
		    String cipherText = null;
		    String ci = null;
			try {
				cipherText = passAuthUtil.encrypt(algorithm, profile.getPassword(), key, ivParameterSpec);
				ci = passAuthUtil.encrypt(algorithm, password, key, ivParameterSpec);

			} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException
					| InvalidAlgorithmParameterException | BadPaddingException | IllegalBlockSizeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    
	    String plainText = null;
	    String pl = null;
		try {
			String ps = profile.getPassword();
			System.out.println(ps); 
			plainText = passAuthUtil.decrypt(algorithm, cipherText, key, ivParameterSpec);
			pl = passAuthUtil.decrypt(algorithm, ps, key, ivParameterSpec);

			System.out.println(plainText);
			System.out.println(pl);
			System.out.println(ci);
			System.out.println(cipherText);
			System.out.println(profile.getPassword());
		} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException
				| InvalidAlgorithmParameterException | BadPaddingException | IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    if (plainText.equals(password)) {
	    	System.out.println("alike");
	    }else {
	    	System.out.println("nope");
	    }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/login.jsp");
        dispatcher.forward(request, response);
	}

}
